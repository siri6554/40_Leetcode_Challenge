class Solution {
    public double findMedianSortedArrays(int[] nums1, int[] nums2) {
        if (nums1.length > nums2.length) return findMedianSortedArrays(nums2, nums1);
        int m = nums1.length, n = nums2.length, low = 0, high = m;
        while (low <= high) {
            int i = low + (high - low) / 2, j = (m + n + 1) / 2 - i;
            int l1 = i == 0 ? Integer.MIN_VALUE : nums1[i - 1];
            int r1 = i == m ? Integer.MAX_VALUE : nums1[i];
            int l2 = j == 0 ? Integer.MIN_VALUE : nums2[j - 1];
            int r2 = j == n ? Integer.MAX_VALUE : nums2[j];
            if (l1 <= r2 && l2 <= r1) {
                if ((m + n) % 2 == 0)
                    return ((double)Math.max(l1, l2) + Math.min(r1, r2)) / 2;
                return Math.max(l1, l2);
            } else if (l1 > r2) high = i - 1;
            else low = i + 1;
        }
        return 0.0;
    }
}
