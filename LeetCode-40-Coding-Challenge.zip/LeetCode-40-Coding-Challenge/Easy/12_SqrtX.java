class Solution {
    public int mySqrt(int x) {
        int l = 0, r = Math.min(x, 46340), ans = 0;
        while (l <= r) {
            int mid = l + (r - l) / 2;
            if ((long) mid * mid <= x) { ans = mid; l = mid + 1; }
            else r = mid - 1;
        }
        return ans;
    }
}
