import java.util.*;

class Solution {
    public int lengthOfLongestSubstring(String s) {
        Set<Character> set = new HashSet<>();
        int left = 0, best = 0;
        for (int right = 0; right < s.length(); right++) {
            while (set.contains(s.charAt(right))) set.remove(s.charAt(left++));
            set.add(s.charAt(right));
            best = Math.max(best, right - left + 1);
        }
        return best;
    }
}
